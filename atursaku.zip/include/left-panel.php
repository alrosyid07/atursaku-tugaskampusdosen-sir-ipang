 
 <aside id="left-panl" class="left-panel"  >
        <nav class="navbar navbar-expand-sm navbar-default"> 

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav navigasi">
                  
                    <li class="menu-item">
                     
                        <a href="home.php" ><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>
                    <li class="menu-title">Menu</li>
                    <li class="menu-item">
                        <a href="?page=masuk" > <i class="menu-icon pe-7f-cash"></i>Kas Masuk</a>    
                    </li>
                    <li class="menu-item">
                        <a href="?page=keluar" > <i class="menu-icon pe-7f-cart"></i>Kas Keluar</a>    
                    </li>
                    <li class="menu-item">
                        <a href="?page=rekap"  > <i class="menu-icon ti-clipboard"></i>Rekapitulasi</a>    
                    </li>
                    <li class="menu-item">
                        <a href="?page=user"  > <i class="menu-icon pe-7f-users"></i>Manajemen User</a>    
                    </li>
                    
                    
                   
                </ul>
            </div>
        </nav>
 
    </aside>
    
<aside id="left-panel" class="left-panel"  >
        <nav class="navbar navbar-expand-sm navbar-default"> 

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav navigasi">
                   
                    <li class="menu-item">
                     
                        <a class="nav-link" href="home.php" ><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>
                    <li class="menu-title">Menu</li>
                    <li class="menu-item">
                        <a class="nav-link" href="?page=masuk" > <i class="menu-icon pe-7f-cash"></i>Kas Masuk</a>    
                    </li>
                    <li class="menu-item">
                        <a class="nav-link" href="?page=keluar" > <i class="menu-icon pe-7f-cart"></i>Kas Keluar</a>    
                    </li>
                    <li class="menu-item">
                        <a class="nav-link" href="?page=rekap"  > <i class="menu-icon ti-clipboard"></i>Rekapitulasi</a>    
                    </li>
                    <li class="menu-item">
                        <a class="nav-link" href="?page=user"  > <i class="menu-icon pe-7f-users"></i>Manajemen User</a>    
                    </li>
                
                    
                   
                </ul>
            </div>
        </nav>
 
    </aside>
    
